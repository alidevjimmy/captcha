<?php

$apiExceptions = [
  1000 => 'SUCCESS',
  1001 => 'AUTH_TOKEN_ERR',
  1002 => 'API_TOKEN_ERR',
  1003 => 'CODE_EXPIRED_ERR',
  1003 => 'CODE_EXPIRED_ERR',
  1004 => 'WRONG_CODE_ERR',
  1005 => 'USED_ERR'
];
